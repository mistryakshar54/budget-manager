import React, { Component } from 'react';
import { BrowserRouter as Router, Route, Link } from "react-router-dom";
import {connect} from 'react-redux';
import { Button } from 'react-bootstrap';

class AppLayout  extends Component{

    render(){
        return(
            <div className="row">
                <div className="container-fluid">
                    <h1>Trying to access store here!!</h1>
                    <Button variant="primary">Primary</Button>

                </div>
            </div>
        );
    }
}

const mapStateToProps = (state) => {
    debugger
    return {
        paymentDataArr : state.paymentData,
        requestState : state.apiRequest
    }
}

export default connect(mapStateToProps)(AppLayout);

