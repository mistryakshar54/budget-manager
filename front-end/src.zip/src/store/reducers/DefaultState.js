export const initialState = {
    paymentData : [],
    incomeData : [],
    expenseData : [],
    categoryData : [],
    apiRequest : {
        message : '',
        status : '',
        apiInProcess : false
    }
};