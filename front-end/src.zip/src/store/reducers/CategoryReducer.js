import {initialState} from './DefaultState';
const CategoryReducer  = ( state = initialState , action ) => {
    return {
        state
    }
};

export default CategoryReducer;