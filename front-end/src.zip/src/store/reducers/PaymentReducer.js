import {initialState} from './DefaultState';

const PaymentReducer  = ( state = initialState , action ) => {
    debugger;
    switch(action.type){
        case 'ADD_PAYMENT_METHOD' : {
            let paymentDataArr = Object.assign([] , state.paymentData);
            return{
                ...state,
                paymentData : paymentDataArr.concat(action.payload)
            }
           
        }
        case 'EDIT_PAYMENT_METHOD' : {

            let paymentDataArr = Object.assign([] , state.paymentData);
            let matchIndex = -1;
            paymentDataArr.forEach( (item , index) => {
                if(item.id === action.payload.id)
                {
                    matchIndex = index;
                }
            });
            if(matchIndex > -1)
            {
                paymentDataArr[matchIndex] = action.payload;
                return{
                    ...state,
                    paymentData : paymentDataArr
                }
            }
            else
            {
                return{
                   state
                }
            }
        }
        case 'DELETE_PAYMENT_METHOD' : {

            let paymentDataArr = Object.assign([] , state.paymentData);
            let matchIndex = -1;
            paymentDataArr.forEach( (item , index) => {
                if(item.id === action.payload.id)
                {
                    matchIndex = index;
                }
            });
            if(matchIndex > -1)
            {
                paymentDataArr.splice(matchIndex , 1);
                return{
                    ...state,
                    paymentData : paymentDataArr
                }
            }
            else
            {
                return{
                   state
                }
            }
        }
        case 'FETCH_PAYMENT_METHOD' : {

            return {
                state
            }
        }
        case 'SUCCESS_PAYMENT_METHOD' : {
            let apiReqStatus = Object.assign({} , state.apiRequest);
            apiReqStatus.message="Success";
            apiReqStatus.status=200;
            apiReqStatus.apiInProcess=false;
            return {
                ...state,
                apiRequest : apiReqStatus
            }
        }
        case 'ERROR_PAYMENT_METHOD' : {
            let apiReqStatus = Object.assign({} , state.apiRequest);
            apiReqStatus.message="Error" + action.payload.error;
            apiReqStatus.status=action.payload.status;
            apiReqStatus.apiInProcess=false;
            return {
                ...state,
                apiRequest : apiReqStatus
            }
        }
        case 'IN_PROCESS_PAYMENT_METHOD' : {

            let apiReqStatus = Object.assign({} , state.apiRequest);
            apiReqStatus.message="In Process";
            apiReqStatus.status=0;
            apiReqStatus.apiInProcess=true;
            return {
                ...state,
                apiRequest : apiReqStatus
            }
        }
        default : {
            return {
                state
            }
        }
    }
};

export default PaymentReducer;