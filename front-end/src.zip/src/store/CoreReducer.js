import IncomeExpenseReducer from './reducers/IncomExpenseReducer'
import CategoryReducer from './reducers/CategoryReducer'
import PaymentReducer from './reducers/PaymentReducer'
import {combineReducers} from 'redux';
import { reducer as formReducer } from 'redux-form'

export const initialState = {
    paymentData : [],
    incomeData : [],
    expenseData : [],
    categoryData : [],
    apiRequest : {
        message : '',
        status : '',
        apiInProcess : false
    }
};

export const rootReducer = combineReducers({
    IncomeExpenseReducer,
    CategoryReducer,
    PaymentReducer,
    form : formReducer
});