

export const fetchPaymentData = ( paymentData ) => {
    return {
        type : 'FETCH_PAYMENT_METHOD',
        payload : paymentData
    }
}

export const successPaymentAction = () => {
    return {
        type : 'SUCCESS_PAYMENT_METHOD'
    }
}

export const errorPaymentAction = ( errorPayload) => {
    return {
        type : 'ERROR_PAYMENT_METHOD',
        payload : errorPayload
    }
}

export const inRequestPaymentAction = () => {
    return {
        type : 'IN_PROCESS_PAYMENT_METHOD'
    }
}

export const addPaymentMethod = ( paymentMethod ) => {
    debugger;
    return{
        type : 'ADD_PAYMENT_METHOD',
        payload : paymentMethod 
    }
}

export const requestNewPaymentMethod = ( paymentMethod ) => {
    debugger;
    return dispatch => {
        dispatch( inRequestPaymentAction() );
        dispatch( addPaymentMethod( paymentMethod ) );
        dispatch( successPaymentAction() );
    }

}