import { createStore , Middleware, applyMiddleware } from 'redux';
import {rootReducer} from './CoreReducer';

export const store = createStore( rootReducer );
